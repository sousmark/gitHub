insert into student (name, birth_Date, email, created_At)
            values  ('Roxanne Garceau', '04/07/2001', 'rgarou@esme.fr', CURRENT_TIMESTAMP());
insert into student (name, birth_Date, email, created_At)
            values  ('Babette Sevier', '04/09/2003', 'bservier@mail.com', CURRENT_TIMESTAMP() - 1.343);
insert into student (name, birth_Date, email, created_At)
            values  ('Musette Garcia', '09/11/2001', 'mgarcia@esme.fr', CURRENT_TIMESTAMP() - 60);
insert into student (name, birth_Date, email, created_At)
            values  ('Orson Leclair', '04/05/1999', 'oleclerec@mail.com', CURRENT_TIMESTAMP());